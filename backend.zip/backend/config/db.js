const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    await mongoose.connect("mongodb://admin:admin12345@ac-hsadt0w-shard-00-00.9uqcejf.mongodb.net:27017,ac-hsadt0w-shard-00-01.9uqcejf.mongodb.net:27017,ac-hsadt0w-shard-00-02.9uqcejf.mongodb.net:27017/guardian-ai?ssl=true&replicaSet=atlas-obrvdi-shard-0&authSource=admin&appName=Cluster0");
    console.log("MongoDB Connected ✅");
  } catch (error) {
    console.log("DB Error:", error);
  }
};

module.exports = connectDB;