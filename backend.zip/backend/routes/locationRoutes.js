const express = require("express");
const router = express.Router();

const Location = require("../models/Location");
const Alert = require("../models/Alert"); // ✅ alert model
const calculateRisk = require("../utils/riskCalculator");
const sendNotification = require("../utils/notify"); // ✅ notification

// Save location + risk + auto alert + notification
router.post("/add", async (req, res) => {
  const { userId, latitude, longitude } = req.body;

  try {
    const riskData = calculateRisk(latitude, longitude);

    // 📍 Save location
    const location = await Location.create({
      userId,
      latitude,
      longitude,
    });

    let alertData = null;
    let notificationMessage = null;

    // 🚨 AUTO ALERT IF HIGH RISK
    if (riskData.status === "HIGH RISK") {
      alertData = await Alert.create({
        userId,
        latitude,
        longitude,
        message: "🚨 AUTO ALERT: High Risk Detected",
      });

      // 📩 SEND NOTIFICATION
      notificationMessage = sendNotification(userId, riskData.status);
    }

    // ✅ Final response
    res.json({
      message: "Location saved",
      location,
      risk: riskData,
      alert: alertData,
      notification: notificationMessage,
    });

  } catch (error) {
    console.log("ERROR:", error);
    res.status(500).json({ message: "Error saving location" });
  }
});

// Test route
router.get("/test", (req, res) => {
  res.send("Location route is working ✅");
});

module.exports = router;