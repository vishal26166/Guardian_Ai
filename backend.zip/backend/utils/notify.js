const sendNotification = (userId, riskStatus) => {
  const message = `
🚨 ALERT NOTIFICATION 🚨
User ID: ${userId}
Risk Level: ${riskStatus}

Please take immediate action!
  `;

  console.log(message); // 👈 simulate sending email/SMS

  return message;
};

module.exports = sendNotification;