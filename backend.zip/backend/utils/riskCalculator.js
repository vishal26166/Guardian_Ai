const calculateRisk = (latitude, longitude) => {
  let risk = 0;

  const hour = new Date().getHours();

  // Night risk
  if (hour >= 20 || hour <= 5) {
    risk += 40;
  }

  // Strong unsafe condition (FOR TESTING)
  if (latitude > 28 && longitude > 77) {
    risk += 70; // 🔥 increased from 30 → 70
  }

  // Random factor
  risk += Math.floor(Math.random() * 20);

  let status = "SAFE";

  if (risk > 60) status = "HIGH RISK";
  else if (risk > 30) status = "MEDIUM RISK";

  return { risk, status };
};

module.exports = calculateRisk;