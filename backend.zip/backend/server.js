const connectDB = require("./config/db");
connectDB();

const express = require("express");
const cors = require("cors"); // ✅ ADD THIS

const app = express();

// ✅ ENABLE CORS (VERY IMPORTANT)
app.use(cors());

// IMPORTANT: allows JSON data
app.use(express.json());

// Routes
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/location", require("./routes/locationRoutes"));

// Test route
app.get("/", (req, res) => {
  res.send("Server is running 🚀");
});

// Test POST
app.post("/test", (req, res) => {
  const data = req.body;

  console.log("Data received:", data);

  res.json({
    message: "Data received successfully",
    yourData: data,
  });
});

// Start server
app.listen(5000, () => {
  console.log("Server started on port 5000");
});